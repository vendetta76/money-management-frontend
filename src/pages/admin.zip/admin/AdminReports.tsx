import AdminLayout from "@/layouts/AdminLayout";

export default function AdminReports() {
    return (
      <AdminLayout>
        <div className="p-4 text-white"></div>
      </AdminLayout>
      );
    }