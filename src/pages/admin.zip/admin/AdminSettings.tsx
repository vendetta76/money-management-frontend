import AdminLayout from "@/layouts/AdminLayout";

export default function AdminSettings() {
    return (
        <AdminLayout>
          <div className="p-4 text-white">⚙️ Admin Settings</div>
        </AdminLayout>
    );
  }