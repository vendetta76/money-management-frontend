import AdminLayout from "@/layouts/AdminLayout";

export default function AdminTransactions() {
  return (
    <AdminLayout>
      <div className="p-4 text-white">💰 Admin Transactions</div>
    </AdminLayout>
  );
}
