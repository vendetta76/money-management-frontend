import React, { useEffect, useState, useRef } from "react";
import {
  collection,
  addDoc,
  updateDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../../lib/firebaseClient";
import { useAuth } from "../../context/AuthContext";
import { usePinLock } from "../../context/PinLockContext";
import LayoutShell from "../../layouts/LayoutShell";
import { Plus, X, Eye, EyeOff } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import WalletPopupHistory from "../../components/WalletPopupHistory";
import WalletTotalOverview from "./WalletTotalOverview";
import WalletGrid from "./WalletGrid";
import WalletFormModal from "./WalletFormModal";
import { useIsBypassed } from "../../hooks/useIsBypassed";
import PageLockAnnouncement from "../../components/admin/PageLockAnnouncement";
import RecalcButtonWithTooltip from "./RecalcButtonWithTooltip";

interface WalletData {
  id: string;
  name: string;
  balance: number;
  currency: string;
  colorStyle: "solid" | "gradient";
  colorValue: string | { start: string; end: string };
  createdAt: any; // Firestore Timestamp or other type
}

const WalletPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, userMeta } = useAuth();
  const { locked: pinLocked, unlock, lock } = usePinLock();
  const { locked, message, isBypassed } = useIsBypassed("wallet");
  const [wallets, setWallets] = useState<WalletData[]>([]);
  const [walletOrder, setWalletOrder] = useState<string[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingWallet, setEditingWallet] = useState<WalletData | null>(null);
  const [selectedWalletId, setSelectedWalletId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showBalance, setShowBalance] = useState(false);
  const [pinLockVisible, setPinLockVisible] = useState(true);
  const [enteredPin, setEnteredPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [isMobile, setIsMobile] = useState(false);
  const [recalcLoading, setRecalcLoading] = useState(false); // State baru
  const pinInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (!pinLocked) setPinLockVisible(false);
    if (pinLockVisible && pinInputRef.current) {
      pinInputRef.current.focus();
    }
  }, [pinLocked, pinLockVisible]);

  useEffect(() => {
    if (!user?.uid) return;
    const q = query(collection(db, "users", user.uid, "wallets"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setWallets(snap.docs.map((d) => ({ id: d.id, ...d.data() } as WalletData)));
      setLoading(false);
    }, (err) => {
      console.error("Firestore error:", err);
      toast.error("Gagal memuat dompet");
      setLoading(false);
    });
    return () => unsub();
  }, [user?.uid]);

  useEffect(() => {
    if (!user?.uid) return;
    const ref = doc(db, "users", user.uid);
    const unsub = onSnapshot(ref, (snap) => {
      if (snap.exists()) {
        setWalletOrder(snap.data().walletOrder || []);
      }
    });
    return () => unsub();
  }, [user?.uid]);

  const handleUnlock = () => {
    const ok = unlock(enteredPin);
    if (ok) {
      setEnteredPin("");
      setPinError("");
      setPinLockVisible(false);
      toast.success("PIN berhasil dibuka!");
    } else {
      setPinError("PIN salah!");
      toast.error("PIN salah!");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleUnlock();
  };

  const walletMap = Object.fromEntries(wallets.map((w) => [w.id, w]));
  const orderedWallets = [
    ...walletOrder.map((id) => walletMap[id]).filter(Boolean),
    ...wallets.filter((w) => !walletOrder.includes(w.id))
  ];

  const totalsByCurrency = orderedWallets.reduce((acc, w) => {
    acc[w.currency] = (acc[w.currency] || 0) + w.balance;
    return acc;
  }, {} as Record<string, number>);

  return (
    <LayoutShell>
      <main
        className={`relative min-h-screen px-4 sm:px-6 py-6 max-w-6xl mx-auto transition-all duration-300 ${pinLockVisible || (locked && !isBypassed) ? "blur-md pointer-events-none" : ""}`}
      >
        {(locked && !isBypassed) && (
          <div className="absolute inset-0 z-40 backdrop-blur-sm bg-black/30 flex items-center justify-center">
            <PageLockAnnouncement
              locked={true}
              message={message}
              currentUserEmail={user?.email || ""}
              currentUserRole={userMeta?.role || ""}
              bypassFor={["Admin", "Staff", "Tester"]}
            />
          </div>
        )}
        {pinLockVisible && (
          <div className="absolute inset-0 z-50 bg-black/50 flex items-center justify-center">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-sm w-full">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">Masukkan PIN</h2>
                <button onClick={() => navigate("/")}><X size={20} /></button>
              </div>
              <input
                ref={pinInputRef}
                type="password"
                value={enteredPin}
                onChange={(e) => setEnteredPin(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter PIN"
                className="w-full p-2 border rounded-lg dark:bg-gray-700 dark:text-white"
              />
              {pinError && <p className="text-red-500 text-sm mt-2">{pinError}</p>}
              <button
                onClick={handleUnlock}
                className="w-full mt-4 bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700"
              >
                Unlock
              </button>
            </div>
          </div>
        )}

        <div className={(locked && !isBypassed) || pinLockVisible ? "pointer-events-none blur-sm" : "relative z-10"}>
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-4">
            <h1 className="text-xl sm:text-2xl font-bold">Dompet Saya</h1>
            <div className="flex flex-wrap gap-2 sm:gap-3">
              <button
                onClick={() => setShowBalance(!showBalance)}
                className="text-sm underline flex items-center gap-1"
              >
                {showBalance ? <EyeOff size={16} /> : <Eye size={16} />} {showBalance ? "Sembunyikan Saldo" : "Tampilkan Saldo"}
              </button>
              <RecalcButtonWithTooltip
                userId={user?.uid || ""}
                setLoading={setRecalcLoading}
                loading={recalcLoading}
              />
              <button
                onClick={() => setShowForm(true)}
                className="bg-purple-600 text-white px-4 py-2 rounded text-sm sm:text-base flex items-center gap-2"
              >
                <Plus size={16} /> Tambah Wallet
              </button>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="h-24 rounded-xl bg-gray-200 dark:bg-gray-700 animate-pulse"
                ></div>
              ))}
            </div>
          ) : (
            <>
              <WalletTotalOverview totalsByCurrency={totalsByCurrency} showBalance={showBalance} />
              <WalletGrid
                userId={user?.uid || ""}
                wallets={orderedWallets}
                showBalance={showBalance}
                isMobile={isMobile}
                onEdit={(id) => {
                  setSelectedWalletId(null);
                  setEditingWallet(walletMap[id]);
                  setShowForm(true);
                }}
                onCardClick={(id) => {
                  if (editingWallet || showForm) return;
                  setSelectedWalletId(id);
                }}
              />
            </>
          )}
        </div>
      </main>

      <WalletFormModal
        isOpen={showForm || !!editingWallet}
        editingData={editingWallet}
        onClose={() => {
          setShowForm(false);
          setEditingWallet(null);
          setSelectedWalletId(null);
        }}
      />

      {selectedWalletId && (
        <WalletPopupHistory
          walletId={selectedWalletId}
          wallets={orderedWallets}
          isOpen={!!selectedWalletId}
          onClose={() => setSelectedWalletId(null)}
        />
      )}
    </LayoutShell>
  );
};

export default WalletPage;